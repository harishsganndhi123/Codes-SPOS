class assembler:
    def __init__(self, filename):
        self.filename = filename
        self.lines = []
        self.optab = {}
        self.bctab = {}
        self.regs = {}
        self.optab["STOP"] = ("IS", "00")
        self.optab["ADD"] = ("IS", "01")
        self.optab["SUB"] = ("IS", "02")
        self.optab["MUL"] = ("IS", "03")
        self.optab["MOVER"] = ("IS", "04")
        self.optab["MOVEM"] = ("IS", "05")
        self.optab["COMP"] = ("IS", "06")
        self.optab["BC"] = ("IS", "07")
        self.optab["DIV"] = ("IS", "08")
        self.optab["READ"] = ("IS", "09")
        self.optab["PRINT"] = ("IS", "10")
        self.optab["START"] = ("AD", "01")
        self.optab["END"] = ("AD", "02")
        self.optab["ORIGIN"] = ("AD", "03")
        self.optab["EQU"] = ("AD", "04")
        self.optab["LTORG"] = ("AD", "05")
        self.optab["DC"] = ("DL", "01")
        self.optab["DS"] = ("DL", "02")
        self.bctab["LT"] = 1
        self.bctab["LE"] = 2
        self.bctab["EQ"] = 3
        self.bctab["GT"] = 4
        self.bctab["GE"] = 5
        self.bctab["ANY"] = 6
        self.regs["AREG"] = 1
        self.regs["BREG"] = 2
        self.regs["CREG"] = 3
        self.regs["DREG"] = 4

        with open(filename, "r") as file:
            for line in file:
                self.lines.append(line.rstrip().split(" "))
        File = open("ic_" + filename, "w")
        File.close()

    def updateSymbol(self, symbol, address):
        for key in self.symbol_table.keys():
            if self.symbol_table[key][0] == symbol:
                if address != -1:
                    self.symbol_table[key] = (symbol, address)
                return key

        self.symbol_table[len(self.symbol_table) + 1] = (symbol, address)
        return len(self.symbol_table)

    def literalAdd(self, literal):
        start = self.pool_table[self.pool_ptr]
        end = self.lit_ptr
        isFound = False
        index = -1
        for i in range(start, end):
            if self.literal_table[i][0] == literal:
                isFound = True
                index = i
                break
        if not isFound:
            index = self.lit_ptr
            self.literal_table[self.lit_ptr] = [literal, -1]
            self.lit_ptr += 1
        return index

    def processLTORG(self, output):
        start = self.pool_table[self.pool_ptr]
        end = self.lit_ptr
        for i in range(start, end):
            val = self.literal_table[i][0].split("=")[1][1:-1]
            output += (f"\n{self.LC} (DL,01) (C,{val})")
            self.literal_table[i][1] = self.LC
            self.LC += 1
        if start != end:
            self.pool_table.append(self.lit_ptr)
            self.pool_ptr += 1
        return output

    def processInstruction(self, label, opcode, params):
        if label != None:
            self.updateSymbol(label, self.LC)

        output = ""
        if opcode == "STOP":
            output = str(self.LC) + " " + f"(IS,00)"
            self.LC += 1
        elif opcode in ["ADD", "SUB", "MUL", "MOVER", "MOVEM", "COMP", "DIV"]:
            reg = params.split(",")[0]
            sym = params.split(",")[1]
            if "=" in sym:
                index = self.literalAdd(sym)
                output = str(
                    self.LC) + " " + f"({self.optab[opcode][0]},{self.optab[opcode][1]}) ({self.regs[reg]}) (L,{index})"
            else:
                output = str(
                    self.LC) + " " + f"({self.optab[opcode][0]},{self.optab[opcode][1]}) ({self.regs[reg]}) (S,{self.updateSymbol(sym, -1)})"
            self.LC += 1
        elif opcode == "BC":
            pem = params.split(",")[0]
            sym = params.split(",")[1]
            output = str(
                self.LC) + " " + f"({self.optab[opcode][0]},{self.optab[opcode][1]}) ({self.bctab[pem]}) (S,{self.updateSymbol(sym, -1)})"
            self.LC += 1
        elif opcode in ["READ", "PRINT"]:
            sym = params.split(",")[0]
            output = str(self.LC) + " " + \
                f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})"
            self.LC += 1
        elif opcode == "START":
            output = "-x- " + \
                f"({self.optab[opcode][0]},{self.optab[opcode][1]})"
            if params != None:
                self.LC = int(params)
                output += f" (C,{int(params)})"
        elif opcode == "ORIGIN":
            if "+" in params:
                sym = params.split("+")[0]
                num = int(params.split("+")[1])
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1] + num
                self.LC = address
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})+{num}"
            elif "-" in params:
                sym = params.split("-")[0]
                num = int(params.split("-")[1])
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1] - num
                self.LC = address
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})-{num}"
            else:
                sym = params
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1]
                self.LC = address
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})"
        elif opcode == "EQU":
            if "+" in params:
                sym = params.split("+")[0]
                num = int(params.split("+")[1])
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1] + num
                self.updateSymbol(label, address)
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})+{num}"
            elif "-" in params:
                sym = params.split("-")[0]
                num = int(params.split("-")[1])
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1] - num
                self.updateSymbol(label, address)
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})-{num}"
            else:
                sym = params
                address = self.symbol_table[self.updateSymbol(
                    sym, -1)][1]
                self.updateSymbol(label, address)
                output = "-x- " + \
                    f"({self.optab[opcode][0]},{self.optab[opcode][1]}) (S,{self.updateSymbol(sym, -1)})"
        elif opcode in ["END", "LTORG"]:
            output = "-x- " + \
                f"({self.optab[opcode][0]},{self.optab[opcode][1]})"
            output = self.processLTORG(output)
        elif opcode == "DC":
            output = f"{self.LC} ({self.optab[opcode][0]},{self.optab[opcode][1]}) (C,{params})"
            self.LC += 1
        elif opcode == "DS":
            output = f"{self.LC} ({self.optab[opcode][0]},{self.optab[opcode][1]}) (C,{params})"
            self.LC += int(params)

        if output != "":
            with open("ic_" + self.filename, "a") as file:
                file.write(output + "\n")

    def pass1(self):
        self.symbol_table = {}
        self.literal_table = {}
        self.pool_table = [0]
        self.LC = 0
        self.lit_ptr = 0
        self.pool_ptr = 0
        i = 0
        while i < len(self.lines):
            if len(self.lines[i]) == 3:
                self.processInstruction(
                    self.lines[i][0], self.lines[i][1], self.lines[i][2])
            elif len(self.lines[i]) == 2:
                if self.lines[i][0] not in self.optab.keys():
                    self.processInstruction(
                        self.lines[i][0], self.lines[i][0], None)
                else:
                    self.processInstruction(
                        None, self.lines[i][0], self.lines[i][1])
            elif len(self.lines[i]) == 1:
                self.processInstruction(None, self.lines[i][0], None)
            i += 1

        print("symbol table : ")
        print(self.symbol_table)
        print("literal table : ")
        print(self.literal_table)
        print("pool table : ")
        print(self.pool_table)

    def pass2(self):
        self.ic_lines = []
        with open("ic_" + self.filename) as file:
            for line in file:
                self.ic_lines.append(line.rstrip().split(" "))
        i = 0
        output = ""
        while (i < len(self.ic_lines)):
            if self.ic_lines[i][0] != "-x-":
                curr = ""
                print(self.ic_lines[i])
                if self.ic_lines[i][1] == "(DL,01)":
                    c = self.ic_lines[i][2][1:-1].split(",")[1]
                    curr = c.zfill(6)
                    curr = self.ic_lines[i][0] + " " + \
                        curr[:2] + " " + curr[2:3] + " " + curr[3:]
                elif self.ic_lines[i][1] == "(DL,02)":
                    add = int(self.ic_lines[i][0])
                    c = int(self.ic_lines[i][2][1:-1].split(",")[1])
                    for _ in range(c):
                        curr += "\n" + str(add) + " " + "__ _ ___"
                        add += 1
                elif len(self.ic_lines[i]) == 4:
                    inst = self.ic_lines[i][1][1:-1]
                    cod = inst.split(",")[1]
                    reg = self.ic_lines[i][2][1:-1]
                    address = self.ic_lines[i][3][1:-1]
                    lors = address.split(",")[0]
                    offset = address.split(",")[1]
                    finAdd = -1
                    if lors == "L":
                        finAdd = self.literal_table[int(offset)][1]
                    else:
                        finAdd = self.symbol_table[int(offset)][1]
                    curr = f"{cod}{reg}{finAdd}"
                    curr = self.ic_lines[i][0] + " " + \
                        curr[:2] + " " + curr[2:3] + " " + curr[3:]

                elif len(self.ic_lines[i]) == 3:
                    inst = self.ic_lines[i][1][1:-1]
                    cod = inst.split(",")[1]
                    address = self.ic_lines[i][2][1:-1]
                    lors = address.split(",")[0]
                    offset = address.split(",")[1]
                    finAdd = -1
                    if lors == "L":
                        finAdd = self.literal_table[int(offset)][1]
                    else:
                        finAdd = self.symbol_table[int(offset)][1]
                    curr = f"{cod}0{finAdd}"
                    curr = self.ic_lines[i][0] + " " + \
                        curr[:2] + " " + curr[2:3] + " " + curr[3:]
                elif len(self.ic_lines[i]) == 2:
                    inst = self.ic_lines[i][1][1:-1]
                    cod = inst.split(",")[1]
                    curr = f"{cod}".zfill(6)
                    curr = self.ic_lines[i][0] + " " + \
                        curr[:2] + " " + curr[2:3] + " " + curr[3:]
                output += curr+"\n"
            i += 1
        with open("final_" + self.filename, "w") as file:
            file.write(output)


hi = assembler("prog3.asm")
hi.pass1()
hi.pass2()
